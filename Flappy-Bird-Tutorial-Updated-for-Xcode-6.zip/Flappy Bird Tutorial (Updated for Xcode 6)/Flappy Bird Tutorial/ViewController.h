//
//  ViewController.h
//  Flappy Bird Tutorial
//
//  Created by Matt Heaney on 28/02/2014.
//  Copyright (c) 2014 Matt Heaney. All rights reserved.
//

#import <UIKit/UIKit.h>

NSInteger HighScoreNumber;

@interface ViewController : UIViewController
{
    IBOutlet UILabel *HighScore;
    
}
@end
